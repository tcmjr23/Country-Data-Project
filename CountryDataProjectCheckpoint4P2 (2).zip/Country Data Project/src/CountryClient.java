import java.io.File;
import java.util.*;
import junit.framework.*;
import java.io.FileNotFoundException;
/*Troy Mosqueda
 * Client for the Country Data Project
 * starter code provided via Dreyer
 * Checkpoint 5
 * March 9, 2023
 */
//Denise Dreyer
//Client for the Country data project.  It will read form a file
//and analyze the data
//October 6, 2022
public class CountryClient {
	
	public static void main(String[] args) throws FileNotFoundException{
		File inputFile =new File("CountryDataSet.csv");
		Scanner input = new Scanner(inputFile);   
		ArrayList<Country> countries = new ArrayList<Country>();
		int countryCounter = 0;
		String line = input.nextLine();
		System.out.print(line);
		String[] splitLine = line.split(",");
		String series = splitLine[0];
		line = input.nextLine();
		splitLine = line.split(",");
		int count=splitLine.length-1;
		//int[] years = new int[count];  //replaced with arrayList
		ArrayList<Integer> years = new ArrayList<Integer>();
		for (int i=0;i<count;i++) {
			years.add(Integer.parseInt(splitLine[i+1]));
		}
		
		while (input.hasNextLine()) {
			line = input.nextLine();
			splitLine = line.split(",");
			String countryName = splitLine[0];
			//double[] values = new double[count];  replaced with ArrayList
			ArrayList<Double> values = new ArrayList<Double>();
			for (int i=0;i<count;i++) {
				values.add(Double.parseDouble(splitLine[i+1]));
			}
			Country myCountry = new Country(countryName, series, years, values);
			String acronym = myCountry.getAcronym();
			System.out.println(acronym + " for " + years.get(0) + "-" + years.get(years.size()-1));
			System.out.println(myCountry +"\n");
			
			//test
			
			//countries[countryCounter]= myCountry;
		//	countryCounter++;
			//TEST STATEMENTS\
		
		
		} //end of while
		
		
		
		
		input.close();//last line in the main method 
	}
	
	//removes a country with given name from the Country ArrayList
	public static void removeByName(ArrayList<Country> countries, String name) {
		for(int i=0;i<countries.size();i++) {
			if(countries.get(i).getCountry().equals(name)) {
				countries.remove(i);
			}
		}
	}
	
	//removes any country with "no trend" in their data values
	public static void removeNoTrend(ArrayList<Country> countries) {
		for(int i=0;i<countries.size();i++) {
			if(countries.get(i).getTrend().equals("no trend")) {
				countries.remove(i);
				i--;
			}
		}
	}
	
	//curates a list of countries with identical trendTypes - throws exception i parameter is not legal
	public static ArrayList<String> getListBasedOnTrend(ArrayList<Country> countries, String trendType){
		if(! ((trendType.equals("down"))|(trendType.equals("up"))|(trendType.equals("no trend")))){// | !trendType.equals("up") | !trendType.equals("no trend")){
			throw new IllegalArgumentException(trendType + " is not a valid argument");
		}
		ArrayList<String> identikit = new ArrayList<String>();
		for(int i=0;i<countries.size();i++) {
			if(countries.get(i).getTrend().equals(trendType)) {
				identikit.add(countries.get(i).getCountry());
			}
		}return identikit;
	}
}
