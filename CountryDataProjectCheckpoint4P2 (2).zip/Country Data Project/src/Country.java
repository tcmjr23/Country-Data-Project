import java.io.File;
import java.util.*;
import junit.framework.*;
import java.util.Scanner;
/*Troy Mosqueda
 * Country Data Project
 * starter code provided via Dreyer
 * Checkpoint 5
 * March 9, 2023
 */
/*Denise Dreyer
 * December 8, 2022
 * Country class will contain all of the info about a country:
 * it's name, series name, years and data for the series
 * It will also be able to calculate and return information about the 
 * country */
public class Country {

	private String name;
	private String series;
	private ArrayList<Integer> years;
	private ArrayList<Double> values;
	
	//Constructor
	public Country(String name, String series, ArrayList<Integer> years, ArrayList<Double> values) {
		this.name = name;
		this.series = series;
		this.years = years;
		this.values = values;
	}
	
//prints all the pertinent information about a country, nicely formatted
	public String toString() {
		String output="";
		for (int i=0; i < years.size();i++) {
			output +=years.get(i)+"\t";
		}
		output +="\n";
		for (int i=0; i < values.size();i++) {
			double value =Math.round(values.get(i)*100.0)/100.0;
			output +=value+"\t";
		}
		
		if(series.indexOf("(")<0) {
			String test = series.substring(series.indexOf("(")+1);
			if(test.indexOf("(")<0) {
				series = series.substring(0,series.indexOf("("));
			}else {
				String[] placeholder = series.split("(");
				series = "";
				for(int i = 0;i<placeholder.length;i++) {
					if(placeholder[i].indexOf(")")<0) {
						series+=placeholder[i] + " ";
					}
				}
				
			}
		}
		output +="\nThis is the \""+series+"\" for "+name+"\n";
		output +="Minimum: "+min()+"\n"+"Maximum: "+max();
		output+="\n"+"Trending: "+getTrend();
		return output;
	}
	
	//Calculate and returns the smallest data value
	public double min() {
		double min = values.get(0);
		for (int i=1; i<values.size();i++) {
			double data = values.get(i);
			if (data< min) 
				min = data;
		}
		return min;
	}
	
	//Calculate and returns the largest data value
	public double max() {
		double max = values.get(0);
		
		for (int i=1; i<values.size();i++) {
			double data = values.get(i);
			if (data> max) 
				max = data;
		}
		return max;
	}
	
	//	This method returns the units for the stored data.  
	//  The string that is returned should not include parentheses.  
	//  In the example above, a call to getUnits would return:  % of 
	//  population.
	public String getUnits() {
		
		if(this.series.indexOf("(")>=0){
			return this.series.substring(series.indexOf("(")+1,series.indexOf(")"));
		}else {
			return "";
		}
		
	}

	//	This method returns an acronym made of the first letter in each of the words in the series name, but excludes: of, in, the, at, to, by, per, on, a, an.  The acronym should be in ALL CAPS and should not include the units.  In the example above, a call to getAcronym would shorten the data series name Access to electricity to simply return: AE.  (If you�re using something like GDP that is already an acronym, it might help for testing to 
	//  adjust your data file to read �Gross domestic product�.)  
	public String getAcronym() {
		String[] abb;
		if(this.series.indexOf("(")>=0){
			abb = this.series.substring(0,series.indexOf("(")).split(" ");
		}else {
			abb = this.series.split(" ");
		}
		String abbreviation = "";
		for(String word: abb) {
			word = word.toLowerCase();
			if(! (word.equals("of") | word.equals("in") | word.equals("the")
			| word.equals("at") | word.equals("to") | word.equals("by") 
			| word.equals("per") | word.equals("on") | word.equals("a") 
			| word.equals("an"))) {
				abbreviation+=word.substring(0,1);
			}
		}
		abbreviation = abbreviation.toUpperCase();
		return abbreviation;
	}

	//This method returns  �up�, �down�, or �no trend� depending on 
	//which direction the data is trending.  This method must call 
	//the private methods trendsUp and trendsDown.	
	public String getTrend() {
		if(trendsUp()==true) {
			return "up";
		}else if(trendsDown()==true) {
			return "down";
		}
		else {
			return "no trend";
		}
	}

	//	This method returns a boolean representing whether each 
	//  data point is higher than the previous one.  For example, 
	//  the method would return true if the data values were:  
	//  20, 22, 25, 27, 33.  The method would return false if the
	//  data values were:  20, 22, 22, 22, 25, 33.  (Yes, this is 
	//  a gross simplification of something that would be better 
	//  done with regression, but I don�t think anyone is up for 
	//  programming that right now.  Wait� are you?)   ;)
	private boolean trendsUp() {
		for(int i = 1; i<values.size(); i++) {
			if(values.get(i)<=values.get(i-1)) {
				return false;
			}
		}
		return true;
	}

/* 	Same idea as trendsUp� each data point must be lower than the 
 * one that came before, otherwise it will return false.
 */
	private boolean trendsDown() {
		for(int i = 1; i<values.size(); i++) {
			if(values.get(i)>=values.get(i-1)) {
				return false;
			}
		}
		return true;
	}
	
	//returns the country name
	public String getCountry() {
		return this.name;
	}
	
	//returns the series
	public String getSeries() {
		if(series.indexOf("(")>=0) {
			String test = series.substring(series.indexOf("(")+1);
			if(test.indexOf("(")<0) {
				series = series.substring(0,series.indexOf("("));
			}else {
				String[] placeholder = series.split("(");
				series = "";
				for(int i = 0;i<placeholder.length;i++) {
					if(placeholder[i].indexOf(")")<0) {
						series+=placeholder[i] + " ";
					}
				}
				
			}
		}
		return series;
	}
	//returns the years of a given country
	public ArrayList<Integer> getYears() {
		return years;
	}
	//returns the values of a given country
	public ArrayList<Double> getData() {
		return values;
	}
	//sets the series with new parameter
	public void setSeries(String s) {
		series = s;
	}
	//set values field to a new ArrayList
	public void setData(ArrayList<Double> d) {
		values=d;
	}
	
	
	//Checkpoint 5
	
	//adds a new data point for an instance of the Country class
	public void addDataPoint(int year, double newDatum) {
		values.add(newDatum);
		years.add(year);
	}
	
	//edits the date point of a given year
	public void editDataPoint(int year, double newDatum) {
		for(int i=0;i<years.size();i++) {
			if(years.get(i)==year) {
				year = i;
			}
		}
		values.set(year, newDatum);
	}
	
	


	
	
}
